[CmdletBinding()]
param(
    [string]$Project,
    [switch]$SkipExtension
)

$ErrorActionPreference = "Stop"

function Invoke-NativeCommand {
    param([string]$FilePath, [string[]]$Arguments)

    & $FilePath @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed ($LASTEXITCODE): $FilePath $($Arguments -join ' ')"
    }
}

function Add-UnionTypesPackageSource {
    param([string]$ProjectDirectory, [string]$PackageDirectory)

    $configPath = Join-Path $ProjectDirectory "NuGet.config"
    if (Test-Path -LiteralPath $configPath -PathType Leaf) {
        [xml]$config = Get-Content -LiteralPath $configPath -Raw
    }
    else {
        $config = New-Object System.Xml.XmlDocument
        $config.AppendChild($config.CreateXmlDeclaration("1.0", "utf-8", $null)) | Out-Null
        $config.AppendChild($config.CreateElement("configuration")) | Out-Null
    }

    $configuration = $config.SelectSingleNode("/configuration")
    if ($null -eq $configuration) {
        throw "'$configPath' is not a valid NuGet configuration file."
    }

    $sources = $configuration.SelectSingleNode("packageSources")
    if ($null -eq $sources) {
        $sources = $config.CreateElement("packageSources")
        $configuration.AppendChild($sources) | Out-Null
    }

    $sourceName = "UnionTypesLocal"
    $source = $sources.SelectSingleNode("add[@key='$sourceName']")
    if ($null -eq $source) {
        $source = $config.CreateElement("add")
        $source.SetAttribute("key", $sourceName)
        $sources.AppendChild($source) | Out-Null
    }
    $source.SetAttribute("value", $PackageDirectory)

    $mappings = $configuration.SelectSingleNode("packageSourceMapping")
    if ($null -eq $mappings) {
        $mappings = $config.CreateElement("packageSourceMapping")
        $configuration.AppendChild($mappings) | Out-Null
    }

    $mapping = $mappings.SelectSingleNode("packageSource[@key='$sourceName']")
    if ($null -eq $mapping) {
        $mapping = $config.CreateElement("packageSource")
        $mapping.SetAttribute("key", $sourceName)
        $mappings.AppendChild($mapping) | Out-Null
    }

    if ($null -eq $mapping.SelectSingleNode("package[@pattern='UnionTypes']")) {
        $package = $config.CreateElement("package")
        $package.SetAttribute("pattern", "UnionTypes")
        $mapping.AppendChild($package) | Out-Null
    }

    $config.Save($configPath)
}

function Test-PackageSourceMappingEnabled {
    param([string]$ProjectDirectory)

    $directory = Get-Item -LiteralPath $ProjectDirectory
    while ($null -ne $directory) {
        $configPath = Join-Path $directory.FullName "NuGet.config"
        if (Test-Path -LiteralPath $configPath -PathType Leaf) {
            [xml]$config = Get-Content -LiteralPath $configPath -Raw
            if ($null -ne $config.SelectSingleNode("/configuration/packageSourceMapping")) {
                return $true
            }
        }
        $directory = $directory.Parent
    }

    return $false
}

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw "The .NET SDK is required."
}

if ([string]::IsNullOrWhiteSpace($Project)) {
    $projects = @(Get-ChildItem -LiteralPath $PWD -Filter "*.csproj" -File)
    if ($projects.Count -eq 0) {
        throw "No .csproj was found in '$PWD'. Pass -Project <path-to-project.csproj>."
    }
    if ($projects.Count -gt 1) {
        throw "Multiple projects were found in '$PWD'. Pass -Project <path-to-project.csproj>."
    }

    $Project = $projects[0].FullName
}

$projectPath = (Resolve-Path -LiteralPath $Project).Path
if ([IO.Path]::GetExtension($projectPath) -ne ".csproj") {
    throw "'$projectPath' is not a C# project file."
}

$package = Get-ChildItem -LiteralPath $PSScriptRoot -Filter "UnionTypes.*.nupkg" -File |
    Sort-Object Name -Descending |
    Select-Object -First 1
if ($null -eq $package) {
    throw "No UnionTypes NuGet package was found beside this script."
}

$projectDirectory = Split-Path -Parent $projectPath
if (Test-PackageSourceMappingEnabled $projectDirectory) {
    Add-UnionTypesPackageSource $projectDirectory $PSScriptRoot
    Invoke-NativeCommand "dotnet" @("add", $projectPath, "package", "UnionTypes", "--version", $package.BaseName.Substring("UnionTypes.".Length))
}
else {
    Invoke-NativeCommand "dotnet" @("add", $projectPath, "package", "UnionTypes", "--version", $package.BaseName.Substring("UnionTypes.".Length), "--source", $PSScriptRoot)
}

if ($SkipExtension) {
    return
}

if (-not (Get-Command code -ErrorAction SilentlyContinue)) {
    throw "The VS Code 'code' command was not found. Install it from VS Code's Command Palette, or rerun with -SkipExtension."
}

$extension = Get-ChildItem -LiteralPath $PSScriptRoot -Filter "union-types-*.vsix" -File |
    Sort-Object Name -Descending |
    Select-Object -First 1
if ($null -eq $extension) {
    throw "No Union Types VS Code extension was found beside this script."
}

Invoke-NativeCommand "code" @("--install-extension", $extension.FullName, "--force")
Write-Host "Installed UnionTypes in '$projectPath' and installed the Union Types VS Code extension."
